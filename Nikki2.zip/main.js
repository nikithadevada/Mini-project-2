use StudentDB
db.students.insertMany([
{
    rollNo: 101,
    name: "Nikhitha",
    age: 20,
    course: "BSc",
    marks: 85
},
{
    rollNo: 102,
    name: "Priya",
    age: 21,
    course: "BSc",
    marks: 90
},
{
    rollNo: 103,
    name: "Aswini",
    age: 19,
    course: "BCom",
    marks: 78
}
])

db.students.find()
db.students.find({ marks: { $gt: 80 } })
db.students.updateOne(
    { rollNo: 101 },
    { $set: { marks: 88 } }
)
db.students.updateMany(
    {},
    { $set: { city: "Hyderabad" } }
)
db.students.deleteOne({ rollNo: 103 })
db.students.countDocuments()
db.students.find().sort({ marks: -1 })